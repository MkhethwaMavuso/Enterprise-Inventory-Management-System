import type { Metadata } from "next"
import { KpiCards } from "@/components/dashboard/kpi-cards"
import { MovementChart } from "@/components/dashboard/movement-chart"
import { RecentActivity } from "@/components/dashboard/recent-activity"
import { StockAlerts } from "@/components/dashboard/stock-alerts"
import { PageHeader } from "@/components/page-header"

export const metadata: Metadata = { title: "Dashboard Overview" }

export default function DashboardPage() {
  return (
    <>
      <PageHeader
        title="Dashboard Overview"
        description="Real-time snapshot of asset capital, stock health, and inventory movement."
      />
      <KpiCards />
      <div className="grid gap-6 xl:grid-cols-3">
        <MovementChart className="xl:col-span-2" />
        <StockAlerts />
      </div>
      <RecentActivity />
    </>
  )
}
