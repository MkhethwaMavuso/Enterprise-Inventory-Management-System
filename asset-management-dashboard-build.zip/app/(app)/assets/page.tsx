import type { Metadata } from "next"
import { AssetsView } from "@/components/assets/assets-view"

export const metadata: Metadata = { title: "Assets Inventory" }

export default function AssetsPage() {
  return <AssetsView />
}
