"use client"

import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import { movementTrend } from "@/lib/mock-data"

const chartConfig = {
  checkIn: { label: "Check-in", color: "var(--chart-1)" },
  checkOut: { label: "Check-out", color: "var(--chart-2)" },
} satisfies ChartConfig

export function MovementChart({ className }: { className?: string }) {
  const totalIn = movementTrend.reduce((s, p) => s + p.checkIn, 0)
  const totalOut = movementTrend.reduce((s, p) => s + p.checkOut, 0)

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>Inventory Movement</CardTitle>
        <CardDescription>
          Check-in vs check-out over the last 7 days · {totalIn} in, {totalOut} out
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="aspect-auto h-72 w-full">
          <AreaChart data={movementTrend} margin={{ left: -16, right: 8, top: 8 }}>
            <defs>
              <linearGradient id="fillCheckIn" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--color-checkIn)" stopOpacity={0.35} />
                <stop offset="95%" stopColor="var(--color-checkIn)" stopOpacity={0.02} />
              </linearGradient>
              <linearGradient id="fillCheckOut" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--color-checkOut)" stopOpacity={0.35} />
                <stop offset="95%" stopColor="var(--color-checkOut)" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} />
            <XAxis dataKey="date" tickLine={false} axisLine={false} tickMargin={8} />
            <YAxis tickLine={false} axisLine={false} tickMargin={8} width={48} />
            <ChartTooltip cursor={false} content={<ChartTooltipContent indicator="dot" />} />
            <Area
              dataKey="checkIn"
              type="monotone"
              fill="url(#fillCheckIn)"
              stroke="var(--color-checkIn)"
              strokeWidth={2}
            />
            <Area
              dataKey="checkOut"
              type="monotone"
              fill="url(#fillCheckOut)"
              stroke="var(--color-checkOut)"
              strokeWidth={2}
            />
            <ChartLegend content={<ChartLegendContent />} />
          </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
