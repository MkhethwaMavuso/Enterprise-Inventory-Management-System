"use client"

import Link from "next/link"
import { ArrowRightIcon } from "lucide-react"
import { ActivityTable } from "@/components/activity/activity-table"
import { useInventory } from "@/components/inventory-provider"
import { Button } from "@/components/ui/button"
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function RecentActivity() {
  const { activity } = useInventory()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>Latest asset movements and administrative changes</CardDescription>
        <CardAction>
          <Button variant="outline" size="sm" nativeButton={false} render={<Link href="/activity" />}>
            Full log
            <ArrowRightIcon data-icon="inline-end" />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent>
        <ActivityTable entries={activity.slice(0, 6)} />
      </CardContent>
    </Card>
  )
}
