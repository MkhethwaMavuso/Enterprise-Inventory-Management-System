"use client"

import Link from "next/link"
import { ArrowRightIcon, CheckCircle2Icon } from "lucide-react"
import { useInventory } from "@/components/inventory-provider"
import { AssetStatusBadge } from "@/components/status-badges"
import { Button } from "@/components/ui/button"
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty"
import { Progress } from "@/components/ui/progress"
import { getAssetStatus } from "@/lib/inventory"

export function StockAlerts() {
  const { assets } = useInventory()
  const alerts = assets
    .filter((a) => getAssetStatus(a) !== "Available")
    .sort((a, b) => a.quantity / Math.max(a.reorderLevel, 1) - b.quantity / Math.max(b.reorderLevel, 1))
    .slice(0, 5)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Stock Alerts</CardTitle>
        <CardDescription>Items at or below reorder level</CardDescription>
        <CardAction>
          <Button variant="ghost" size="sm" nativeButton={false} render={<Link href="/assets" />}>
            View all
            <ArrowRightIcon data-icon="inline-end" />
          </Button>
        </CardAction>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <CheckCircle2Icon />
              </EmptyMedia>
              <EmptyTitle>All stocked up</EmptyTitle>
              <EmptyDescription>No assets are below their reorder level.</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <ul className="flex flex-col gap-4">
            {alerts.map((asset) => {
              const pct = Math.min(100, Math.round((asset.quantity / Math.max(asset.reorderLevel, 1)) * 100))
              return (
                <li key={asset.id} className="flex flex-col gap-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium">{asset.name}</p>
                      <p className="font-mono text-xs text-muted-foreground">{asset.sku}</p>
                    </div>
                    <AssetStatusBadge status={getAssetStatus(asset)} />
                  </div>
                  <div className="flex items-center gap-3">
                    <Progress value={pct} aria-label={`${asset.name} stock relative to reorder level`} className="flex-1" />
                    <span className="w-16 text-right text-xs tabular-nums text-muted-foreground">
                      {asset.quantity} / {asset.reorderLevel}
                    </span>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  )
}
