"use client"

import { AlertTriangleIcon, BoxesIcon, DollarSignIcon, UsersIcon, type LucideIcon } from "lucide-react"
import { useInventory } from "@/components/inventory-provider"
import { Badge } from "@/components/ui/badge"
import { Card, CardAction, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { formatCompactCurrency, formatCurrency, formatNumber, getAssetStatus } from "@/lib/inventory"

interface Kpi {
  label: string
  value: string
  icon: LucideIcon
  footnote: string
  badge?: { label: string; variant: React.ComponentProps<typeof Badge>["variant"] }
  srValue?: string
}

export function KpiCards() {
  const { assets, users } = useInventory()

  const totalValue = assets.reduce((sum, a) => sum + a.quantity * a.unitPrice, 0)
  const totalUnits = assets.reduce((sum, a) => sum + a.quantity, 0)
  const lowStock = assets.filter((a) => getAssetStatus(a) === "Low Stock").length
  const outOfStock = assets.filter((a) => getAssetStatus(a) === "Out of Stock").length
  const activeUsers = users.filter((u) => u.status === "Active").length

  const kpis: Kpi[] = [
    {
      label: "Total Asset Value",
      value: formatCompactCurrency(totalValue),
      srValue: formatCurrency(totalValue),
      icon: DollarSignIcon,
      footnote: "Capital held across all locations",
      badge: { label: "+4.2%", variant: "success" },
    },
    {
      label: "Total Items in Stock",
      value: formatNumber(totalUnits),
      icon: BoxesIcon,
      footnote: `Across ${assets.length} unique SKUs`,
    },
    {
      label: "Low Stock Alerts",
      value: formatNumber(lowStock + outOfStock),
      icon: AlertTriangleIcon,
      footnote: `${lowStock} low · ${outOfStock} out of stock`,
      badge: lowStock + outOfStock > 0 ? { label: "Action needed", variant: "warning" } : undefined,
    },
    {
      label: "Active Users",
      value: formatNumber(activeUsers),
      icon: UsersIcon,
      footnote: `${users.length - activeUsers} inactive accounts`,
    },
  ]

  return (
    <section aria-label="Key metrics" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {kpis.map((kpi) => (
        <Card key={kpi.label}>
          <CardHeader>
            <CardDescription className="flex items-center gap-2">
              <kpi.icon className="size-4" aria-hidden="true" />
              {kpi.label}
            </CardDescription>
            <CardTitle className="text-3xl font-semibold tabular-nums">
              <span aria-hidden={kpi.srValue ? true : undefined}>{kpi.value}</span>
              {kpi.srValue && <span className="sr-only">{kpi.srValue}</span>}
            </CardTitle>
            {kpi.badge && (
              <CardAction>
                <Badge variant={kpi.badge.variant}>{kpi.badge.label}</Badge>
              </CardAction>
            )}
          </CardHeader>
          <CardFooter className="text-sm text-muted-foreground">{kpi.footnote}</CardFooter>
        </Card>
      ))}
    </section>
  )
}
