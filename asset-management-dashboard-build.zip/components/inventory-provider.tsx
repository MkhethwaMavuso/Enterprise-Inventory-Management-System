"use client"

import * as React from "react"
import {
  createUserAction,
  deleteAssetAction,
  saveAssetAction,
  updateAssetQuantityAction,
  type AssetInput,
  type CreateUserInput,
  type QuantityOperation,
} from "@/lib/actions"
import { CURRENT_USER, initialActivity, initialAssets, initialUsers } from "@/lib/mock-data"
import type { ActionResult, ActivityAction, ActivityLog, Asset, User } from "@/lib/types"

interface InventoryContextValue {
  assets: Asset[]
  users: User[]
  activity: ActivityLog[]
  currentUser: User
  adjustQuantity: (asset: Asset, amount: number, operation: QuantityOperation) => Promise<ActionResult<unknown>>
  saveAsset: (input: AssetInput, id?: string) => Promise<ActionResult<Asset>>
  deleteAsset: (asset: Asset) => Promise<ActionResult<unknown>>
  createUser: (input: CreateUserInput) => Promise<ActionResult<User>>
  toggleUserStatus: (userId: string) => void
}

const InventoryContext = React.createContext<InventoryContextValue | null>(null)

export function InventoryProvider({ children }: { children: React.ReactNode }) {
  const [assets, setAssets] = React.useState<Asset[]>(initialAssets)
  const [users, setUsers] = React.useState<User[]>(initialUsers)
  const [activity, setActivity] = React.useState<ActivityLog[]>(initialActivity)

  const log = React.useCallback(
    (action: ActivityAction, entry: Pick<ActivityLog, "assetName" | "sku" | "quantity">) => {
      setActivity((prev) => [
        {
          id: `log_${crypto.randomUUID().slice(0, 8)}`,
          action,
          performedBy: CURRENT_USER.name,
          timestamp: new Date().toISOString(),
          status: "Completed",
          ...entry,
        },
        ...prev,
      ])
    },
    [],
  )

  const adjustQuantity = React.useCallback<InventoryContextValue["adjustQuantity"]>(
    async (asset, amount, operation) => {
      const result = await updateAssetQuantityAction({
        assetId: asset.id,
        currentQuantity: asset.quantity,
        amount,
        operation,
      })
      if (result.ok) {
        setAssets((prev) => prev.map((a) => (a.id === asset.id ? { ...a, quantity: result.data.quantity } : a)))
        log(operation, { assetName: asset.name, sku: asset.sku, quantity: amount })
      }
      return result
    },
    [log],
  )

  const saveAsset = React.useCallback<InventoryContextValue["saveAsset"]>(
    async (input, id) => {
      const result = await saveAssetAction({ ...input, id })
      if (result.ok) {
        const saved = result.data
        setAssets((prev) => (id ? prev.map((a) => (a.id === id ? saved : a)) : [saved, ...prev]))
        log(id ? "UPDATE" : "CREATE", { assetName: saved.name, sku: saved.sku, quantity: id ? undefined : saved.quantity })
      }
      return result
    },
    [log],
  )

  const deleteAsset = React.useCallback<InventoryContextValue["deleteAsset"]>(
    async (asset) => {
      const result = await deleteAssetAction(asset.id)
      if (result.ok) {
        setAssets((prev) => prev.filter((a) => a.id !== asset.id))
        log("DELETE", { assetName: asset.name, sku: asset.sku })
      }
      return result
    },
    [log],
  )

  const createUser = React.useCallback<InventoryContextValue["createUser"]>(
    async (input) => {
      if (users.some((u) => u.email === input.email.trim().toLowerCase())) {
        return { ok: false, error: "A user with this email already exists." }
      }
      const result = await createUserAction(input)
      if (result.ok) {
        setUsers((prev) => [result.data, ...prev])
        log("USER_CREATED", { assetName: result.data.name })
      }
      return result
    },
    [log, users],
  )

  const toggleUserStatus = React.useCallback((userId: string) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, status: u.status === "Active" ? "Inactive" : "Active" } : u)),
    )
  }, [])

  const value = React.useMemo(
    () => ({
      assets,
      users,
      activity,
      currentUser: CURRENT_USER,
      adjustQuantity,
      saveAsset,
      deleteAsset,
      createUser,
      toggleUserStatus,
    }),
    [assets, users, activity, adjustQuantity, saveAsset, deleteAsset, createUser, toggleUserStatus],
  )

  return <InventoryContext.Provider value={value}>{children}</InventoryContext.Provider>
}

export function useInventory() {
  const context = React.useContext(InventoryContext)
  if (!context) throw new Error("useInventory must be used within an InventoryProvider")
  return context
}
