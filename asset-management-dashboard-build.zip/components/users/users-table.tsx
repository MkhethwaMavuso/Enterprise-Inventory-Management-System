"use client"

import { useInventory } from "@/components/inventory-provider"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { formatDate, getInitials } from "@/lib/inventory"
import type { User } from "@/lib/types"

export function UsersTable({ users }: { users: User[] }) {
  const { currentUser, toggleUserStatus } = useInventory()

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>User</TableHead>
          <TableHead>Role</TableHead>
          <TableHead>Joined</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="text-right">Active</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {users.map((user) => {
          const isSelf = user.id === currentUser.id
          return (
            <TableRow key={user.id}>
              <TableCell>
                <div className="flex items-center gap-3">
                  <Avatar className="size-8">
                    <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                  </Avatar>
                  <div className="flex min-w-0 flex-col">
                    <span className="truncate font-medium">
                      {user.name}
                      {isSelf && <span className="text-muted-foreground"> (you)</span>}
                    </span>
                    <span className="truncate text-xs text-muted-foreground">{user.email}</span>
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <Badge variant={user.role === "ADMIN" ? "default" : "secondary"} className="font-mono">
                  {user.role}
                </Badge>
              </TableCell>
              <TableCell className="text-muted-foreground">{formatDate(user.createdAt)}</TableCell>
              <TableCell>
                <Badge variant={user.status === "Active" ? "success" : "outline"}>{user.status}</Badge>
              </TableCell>
              <TableCell className="text-right">
                <Switch
                  checked={user.status === "Active"}
                  onCheckedChange={() => toggleUserStatus(user.id)}
                  disabled={isSelf}
                  aria-label={`Toggle access for ${user.name}`}
                />
              </TableCell>
            </TableRow>
          )
        })}
      </TableBody>
    </Table>
  )
}
