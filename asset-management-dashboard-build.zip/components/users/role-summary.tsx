import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { USER_ROLES, type User, type UserRole } from "@/lib/types"

export const ROLE_DESCRIPTIONS: Record<UserRole, string> = {
  ADMIN: "Full access, user management",
  MANAGER: "Manage assets and approve requests",
  STAFF: "Check out and return assets",
  EXECUTIVE: "Read-only reporting access",
}

export function RoleSummary({ users }: { users: User[] }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {USER_ROLES.map((role) => (
        <Card key={role} size="sm">
          <CardHeader>
            <CardDescription className="font-mono text-xs tracking-wide">{role}</CardDescription>
            <CardTitle className="text-2xl tabular-nums">{users.filter((u) => u.role === role).length}</CardTitle>
            <CardDescription>{ROLE_DESCRIPTIONS[role]}</CardDescription>
          </CardHeader>
        </Card>
      ))}
    </div>
  )
}
