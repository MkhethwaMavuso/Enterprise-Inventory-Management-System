"use client"

import * as React from "react"
import { toast } from "sonner"
import { useInventory } from "@/components/inventory-provider"
import { ROLE_DESCRIPTIONS } from "@/components/users/role-summary"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Spinner } from "@/components/ui/spinner"
import { USER_ROLES, type UserRole } from "@/lib/types"

const roleItems = USER_ROLES.map((r) => ({ label: r, value: r }))

interface CreateUserDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function CreateUserDialog({ open, onOpenChange }: CreateUserDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">{open && <CreateUserForm onDone={() => onOpenChange(false)} />}</DialogContent>
    </Dialog>
  )
}

function CreateUserForm({ onDone }: { onDone: () => void }) {
  const { createUser } = useInventory()
  const [role, setRole] = React.useState<UserRole>("STAFF")
  const [error, setError] = React.useState<string | null>(null)
  const [isPending, startTransition] = React.useTransition()

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    setError(null)
    startTransition(async () => {
      const result = await createUser({
        name: String(form.get("name") ?? ""),
        email: String(form.get("email") ?? ""),
        password: String(form.get("password") ?? ""),
        role,
      })
      if (!result.ok) {
        setError(result.error)
        return
      }
      toast.success("User created", { description: `${result.data.name} · ${result.data.role}` })
      onDone()
    })
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      <DialogHeader>
        <DialogTitle>Create user</DialogTitle>
        <DialogDescription>Add a team member and assign their access level.</DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <Field>
          <FieldLabel htmlFor="user-name">Full name</FieldLabel>
          <Input id="user-name" name="name" required minLength={2} autoComplete="name" placeholder="Jane Cooper" />
        </Field>
        <Field>
          <FieldLabel htmlFor="user-email">Email</FieldLabel>
          <Input id="user-email" name="email" type="email" required autoComplete="email" placeholder="jane@company.com" />
        </Field>
        <Field>
          <FieldLabel htmlFor="user-password">Temporary password</FieldLabel>
          <Input id="user-password" name="password" type="password" required minLength={8} autoComplete="new-password" />
          <FieldDescription>At least 8 characters. The user can change it after signing in.</FieldDescription>
        </Field>
        <Field>
          <FieldLabel htmlFor="user-role">Role</FieldLabel>
          <Select items={roleItems} value={role} onValueChange={(v) => v && setRole(v as UserRole)}>
            <SelectTrigger id="user-role" className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                {roleItems.map((item) => (
                  <SelectItem key={item.value} value={item.value}>
                    {item.label}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
          <FieldDescription>{ROLE_DESCRIPTIONS[role]}</FieldDescription>
        </Field>
        {error && (
          <Field data-invalid>
            <FieldError>{error}</FieldError>
          </Field>
        )}
      </FieldGroup>
      <DialogFooter>
        <DialogClose render={<Button type="button" variant="outline" />}>Cancel</DialogClose>
        <Button type="submit" disabled={isPending}>
          {isPending && <Spinner data-icon="inline-start" />}
          Create user
        </Button>
      </DialogFooter>
    </form>
  )
}
