"use client"

import * as React from "react"
import { UserPlusIcon } from "lucide-react"
import { useInventory } from "@/components/inventory-provider"
import { PageHeader } from "@/components/page-header"
import { CreateUserDialog } from "@/components/users/create-user-dialog"
import { RoleSummary } from "@/components/users/role-summary"
import { UsersTable } from "@/components/users/users-table"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export function UsersView() {
  const { users } = useInventory()
  const [open, setOpen] = React.useState(false)

  return (
    <>
      <PageHeader
        title="Users & Roles"
        description="Invite team members and control what they can access."
        actions={
          <Button onClick={() => setOpen(true)}>
            <UserPlusIcon data-icon="inline-start" />
            Create User
          </Button>
        }
      />
      <RoleSummary users={users} />
      <Card>
        <CardHeader>
          <CardTitle>Team Members</CardTitle>
          <CardDescription>{users.length} users in your organization</CardDescription>
        </CardHeader>
        <CardContent>
          <UsersTable users={users} />
        </CardContent>
      </Card>
      <CreateUserDialog open={open} onOpenChange={setOpen} />
    </>
  )
}
