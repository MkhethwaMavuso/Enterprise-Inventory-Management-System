import { Badge } from "@/components/ui/badge"
import type { ActivityAction, ActivityStatus, AssetStatus, UserRole, UserStatus } from "@/lib/types"

type BadgeVariant = React.ComponentProps<typeof Badge>["variant"]

const assetStatusVariant: Record<AssetStatus, BadgeVariant> = {
  Available: "success",
  "Low Stock": "warning",
  "Out of Stock": "destructive",
}

export function AssetStatusBadge({ status }: { status: AssetStatus }) {
  return <Badge variant={assetStatusVariant[status]}>{status}</Badge>
}

const activityStatusVariant: Record<ActivityStatus, BadgeVariant> = {
  Completed: "success",
  Pending: "warning",
  Flagged: "destructive",
}

export function ActivityStatusBadge({ status }: { status: ActivityStatus }) {
  return <Badge variant={activityStatusVariant[status]}>{status}</Badge>
}

export const ACTION_LABELS: Record<ActivityAction, string> = {
  CHECK_OUT: "Check-out",
  CHECK_IN: "Check-in",
  RESTOCK: "Restock",
  CREATE: "Created",
  UPDATE: "Updated",
  DELETE: "Deleted",
  USER_CREATED: "User added",
}

export function ActionBadge({ action }: { action: ActivityAction }) {
  const variant: BadgeVariant = action === "DELETE" ? "destructive" : action === "CHECK_OUT" ? "default" : "secondary"
  return <Badge variant={variant}>{ACTION_LABELS[action]}</Badge>
}

const roleVariant: Record<UserRole, BadgeVariant> = {
  ADMIN: "default",
  EXECUTIVE: "secondary",
  MANAGER: "secondary",
  STAFF: "outline",
}

export function RoleBadge({ role }: { role: UserRole }) {
  return <Badge variant={roleVariant[role]}>{role}</Badge>
}

export function UserStatusBadge({ status }: { status: UserStatus }) {
  return <Badge variant={status === "Active" ? "success" : "outline"}>{status}</Badge>
}
