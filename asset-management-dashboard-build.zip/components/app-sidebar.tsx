"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { ActivityIcon } from "lucide-react"
import { NavUser } from "@/components/nav-user"
import { NAV_ITEMS } from "@/lib/navigation"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar"
import { useInventory } from "@/components/inventory-provider"
import { getAssetStatus } from "@/lib/inventory"

export function AppSidebar() {
  const pathname = usePathname()
  const { assets } = useInventory()
  const alertCount = assets.filter((a) => getAssetStatus(a) !== "Available").length

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" render={<Link href="/dashboard" />} tooltip="AssetPulse">
              <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
                <ActivityIcon className="size-4" aria-hidden="true" />
              </div>
              <div className="grid flex-1 text-left leading-tight">
                <span className="truncate font-semibold">AssetPulse</span>
                <span className="truncate text-xs text-muted-foreground">Enterprise Inventory</span>
              </div>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Workspace</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {NAV_ITEMS.map((item) => {
                const isActive = pathname === item.href || pathname.startsWith(`${item.href}/`)
                return (
                  <SidebarMenuItem key={item.href}>
                    <SidebarMenuButton
                      isActive={isActive}
                      tooltip={item.title}
                      render={<Link href={item.href} aria-current={isActive ? "page" : undefined} />}
                    >
                      <item.icon />
                      <span>{item.title}</span>
                    </SidebarMenuButton>
                    {item.href === "/assets" && alertCount > 0 && (
                      <SidebarMenuBadge aria-label={`${alertCount} stock alerts`}>{alertCount}</SidebarMenuBadge>
                    )}
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        <NavUser />
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
