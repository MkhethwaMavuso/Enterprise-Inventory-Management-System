"use client"

import * as React from "react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Field, FieldContent, FieldDescription, FieldGroup, FieldLabel, FieldSeparator } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"

const NOTIFICATIONS = [
  { id: "low-stock", label: "Low stock alerts", description: "Email managers when an asset falls below its reorder level.", defaultChecked: true },
  { id: "out-of-stock", label: "Out of stock alerts", description: "Notify admins immediately when stock reaches zero.", defaultChecked: true },
  { id: "weekly", label: "Weekly summary", description: "Send executives a weekly inventory valuation report.", defaultChecked: false },
]

export function SettingsForm() {
  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    toast.success("Settings saved")
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Organization</CardTitle>
          <CardDescription>Basic details shown across the dashboard.</CardDescription>
        </CardHeader>
        <CardContent>
          <FieldGroup>
            <Field>
              <FieldLabel htmlFor="org-name">Organization name</FieldLabel>
              <Input id="org-name" name="orgName" defaultValue="Acme Corporation" />
            </Field>
            <Field>
              <FieldLabel htmlFor="org-currency">Currency</FieldLabel>
              <Input id="org-currency" name="currency" defaultValue="USD" disabled />
              <FieldDescription>All asset values are reported in US dollars.</FieldDescription>
            </Field>
            <Field>
              <FieldLabel htmlFor="default-reorder">Default reorder level</FieldLabel>
              <Input id="default-reorder" name="reorderLevel" type="number" min={0} defaultValue={5} />
            </Field>
          </FieldGroup>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Notifications</CardTitle>
          <CardDescription>Choose which inventory events trigger alerts.</CardDescription>
        </CardHeader>
        <CardContent>
          <FieldGroup>
            {NOTIFICATIONS.map((n, i) => (
              <React.Fragment key={n.id}>
                {i > 0 && <FieldSeparator />}
                <Field orientation="horizontal">
                  <FieldContent>
                    <FieldLabel htmlFor={n.id}>{n.label}</FieldLabel>
                    <FieldDescription>{n.description}</FieldDescription>
                  </FieldContent>
                  <Switch id={n.id} name={n.id} defaultChecked={n.defaultChecked} />
                </Field>
              </React.Fragment>
            ))}
          </FieldGroup>
        </CardContent>
      </Card>
      <div className="flex justify-end lg:col-span-2">
        <Button type="submit">Save settings</Button>
      </div>
    </form>
  )
}
