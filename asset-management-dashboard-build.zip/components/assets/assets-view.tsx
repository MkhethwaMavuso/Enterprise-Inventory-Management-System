"use client"

import * as React from "react"
import { PlusIcon, SearchIcon } from "lucide-react"
import { AssetFormDialog } from "@/components/assets/asset-form-dialog"
import { AssetsTable } from "@/components/assets/assets-table"
import { DeleteAssetDialog } from "@/components/assets/delete-asset-dialog"
import { QuantityDialog } from "@/components/assets/quantity-dialog"
import { useInventory } from "@/components/inventory-provider"
import { PageHeader } from "@/components/page-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { InputGroup, InputGroupAddon, InputGroupInput } from "@/components/ui/input-group"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getAssetStatus } from "@/lib/inventory"
import type { QuantityOperation } from "@/lib/actions"
import { ASSET_CATEGORIES, type Asset } from "@/lib/types"

const categoryItems = [{ label: "All categories", value: "all" }, ...ASSET_CATEGORIES.map((c) => ({ label: c, value: c }))]
const statusItems = [
  { label: "All statuses", value: "all" },
  { label: "Available", value: "Available" },
  { label: "Low Stock", value: "Low Stock" },
  { label: "Out of Stock", value: "Out of Stock" },
]

type DialogState =
  | { type: "form"; asset?: Asset }
  | { type: "quantity"; asset: Asset; operation: QuantityOperation }
  | { type: "delete"; asset: Asset }
  | null

export function AssetsView() {
  const { assets } = useInventory()
  const [query, setQuery] = React.useState("")
  const [category, setCategory] = React.useState("all")
  const [status, setStatus] = React.useState("all")
  const [dialog, setDialog] = React.useState<DialogState>(null)

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase()
    return assets.filter((a) => {
      if (category !== "all" && a.category !== category) return false
      if (status !== "all" && getAssetStatus(a) !== status) return false
      if (!q) return true
      return a.name.toLowerCase().includes(q) || a.sku.toLowerCase().includes(q) || a.location.toLowerCase().includes(q)
    })
  }, [assets, query, category, status])

  const closeDialog = () => setDialog(null)

  return (
    <>
      <PageHeader
        title="Assets Inventory"
        description="Manage SKUs, track quantities, and record check-outs and restocks."
        actions={
          <Button onClick={() => setDialog({ type: "form" })}>
            <PlusIcon data-icon="inline-start" />
            Add Asset
          </Button>
        }
      />

      <Card>
        <CardHeader>
          <CardTitle>All Assets</CardTitle>
          <CardDescription>
            Showing {filtered.length} of {assets.length} assets
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex flex-col gap-2 md:flex-row">
            <InputGroup className="md:max-w-sm">
              <InputGroupAddon>
                <SearchIcon />
              </InputGroupAddon>
              <InputGroupInput
                type="search"
                placeholder="Search by name, SKU, or location…"
                aria-label="Search assets"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </InputGroup>
            <div className="flex gap-2">
              <Select items={categoryItems} value={category} onValueChange={(v) => setCategory(v ?? "all")}>
                <SelectTrigger aria-label="Filter by category" className="w-full md:w-44">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    {categoryItems.map((item) => (
                      <SelectItem key={item.value} value={item.value}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
              <Select items={statusItems} value={status} onValueChange={(v) => setStatus(v ?? "all")}>
                <SelectTrigger aria-label="Filter by status" className="w-full md:w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    {statusItems.map((item) => (
                      <SelectItem key={item.value} value={item.value}>
                        {item.label}
                      </SelectItem>
                    ))}
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
          </div>

          <AssetsTable
            assets={filtered}
            onEdit={(asset) => setDialog({ type: "form", asset })}
            onDelete={(asset) => setDialog({ type: "delete", asset })}
            onAdjust={(asset, operation) => setDialog({ type: "quantity", asset, operation })}
          />
        </CardContent>
      </Card>

      <AssetFormDialog
        open={dialog?.type === "form"}
        asset={dialog?.type === "form" ? dialog.asset : undefined}
        onOpenChange={(open) => !open && closeDialog()}
      />
      {dialog?.type === "quantity" && (
        <QuantityDialog asset={dialog.asset} operation={dialog.operation} onOpenChange={(open) => !open && closeDialog()} />
      )}
      <DeleteAssetDialog
        asset={dialog?.type === "delete" ? dialog.asset : null}
        onOpenChange={(open) => !open && closeDialog()}
      />
    </>
  )
}
