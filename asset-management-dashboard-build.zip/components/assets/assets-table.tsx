"use client"

import { MinusCircleIcon, MoreHorizontalIcon, PencilIcon, PlusCircleIcon, Trash2Icon } from "lucide-react"
import { AssetStatusBadge } from "@/components/status-badges"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { formatCurrency, formatNumber, getAssetStatus } from "@/lib/inventory"
import type { QuantityOperation } from "@/lib/actions"
import type { Asset } from "@/lib/types"

interface AssetsTableProps {
  assets: Asset[]
  onEdit: (asset: Asset) => void
  onDelete: (asset: Asset) => void
  onAdjust: (asset: Asset, operation: QuantityOperation) => void
}

export function AssetsTable({ assets, onEdit, onDelete, onAdjust }: AssetsTableProps) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>SKU</TableHead>
          <TableHead>Asset Name</TableHead>
          <TableHead>Category</TableHead>
          <TableHead className="text-right">Quantity</TableHead>
          <TableHead className="text-right">Unit Price</TableHead>
          <TableHead className="text-right">Total Value</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="w-12">
            <span className="sr-only">Actions</span>
          </TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {assets.length === 0 ? (
          <TableRow>
            <TableCell colSpan={8} className="h-24 text-center text-muted-foreground">
              No assets match your filters.
            </TableCell>
          </TableRow>
        ) : (
          assets.map((asset) => (
            <TableRow key={asset.id}>
              <TableCell className="font-mono text-xs text-muted-foreground">{asset.sku}</TableCell>
              <TableCell>
                <div className="flex flex-col">
                  <span className="font-medium">{asset.name}</span>
                  <span className="text-xs text-muted-foreground">{asset.location}</span>
                </div>
              </TableCell>
              <TableCell>{asset.category}</TableCell>
              <TableCell className="text-right tabular-nums">{formatNumber(asset.quantity)}</TableCell>
              <TableCell className="text-right tabular-nums">{formatCurrency(asset.unitPrice)}</TableCell>
              <TableCell className="text-right font-medium tabular-nums">
                {formatCurrency(asset.quantity * asset.unitPrice)}
              </TableCell>
              <TableCell>
                <AssetStatusBadge status={getAssetStatus(asset)} />
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger
                    render={<Button variant="ghost" size="icon-sm" aria-label={`Actions for ${asset.name}`} />}
                  >
                    <MoreHorizontalIcon />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="min-w-40">
                    <DropdownMenuGroup>
                      <DropdownMenuItem onClick={() => onAdjust(asset, "CHECK_OUT")} disabled={asset.quantity === 0}>
                        <MinusCircleIcon />
                        Check out
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onAdjust(asset, "RESTOCK")}>
                        <PlusCircleIcon />
                        Restock
                      </DropdownMenuItem>
                    </DropdownMenuGroup>
                    <DropdownMenuSeparator />
                    <DropdownMenuGroup>
                      <DropdownMenuItem onClick={() => onEdit(asset)}>
                        <PencilIcon />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem variant="destructive" onClick={() => onDelete(asset)}>
                        <Trash2Icon />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuGroup>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  )
}
