"use client"

import * as React from "react"
import { toast } from "sonner"
import { useInventory } from "@/components/inventory-provider"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Field, FieldDescription, FieldError, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Spinner } from "@/components/ui/spinner"
import type { QuantityOperation } from "@/lib/actions"
import type { Asset } from "@/lib/types"

interface QuantityDialogProps {
  asset: Asset
  operation: QuantityOperation
  onOpenChange: (open: boolean) => void
}

export function QuantityDialog({ asset, operation, onOpenChange }: QuantityDialogProps) {
  const { adjustQuantity } = useInventory()
  const [amount, setAmount] = React.useState("1")
  const [error, setError] = React.useState<string | null>(null)
  const [isPending, startTransition] = React.useTransition()

  const isCheckOut = operation === "CHECK_OUT"
  const parsed = Number(amount)
  const preview = Number.isInteger(parsed) && parsed > 0 ? asset.quantity + (isCheckOut ? -parsed : parsed) : null

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(null)
    startTransition(async () => {
      const result = await adjustQuantity(asset, parsed, operation)
      if (!result.ok) {
        setError(result.error)
        return
      }
      toast.success(isCheckOut ? "Asset checked out" : "Asset restocked", {
        description: `${parsed} × ${asset.name}`,
      })
      onOpenChange(false)
    })
  }

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <DialogHeader>
            <DialogTitle>{isCheckOut ? "Check out asset" : "Restock asset"}</DialogTitle>
            <DialogDescription>
              {asset.name} · <span className="font-mono">{asset.sku}</span> · {asset.quantity} currently in stock
            </DialogDescription>
          </DialogHeader>
          <FieldGroup>
            <Field data-invalid={error ? true : undefined}>
              <FieldLabel htmlFor="quantity-amount">Quantity</FieldLabel>
              <Input
                id="quantity-amount"
                type="number"
                inputMode="numeric"
                min={1}
                max={isCheckOut ? asset.quantity : undefined}
                step={1}
                required
                autoFocus
                value={amount}
                aria-invalid={error ? true : undefined}
                onChange={(e) => setAmount(e.target.value)}
              />
              {error ? (
                <FieldError>{error}</FieldError>
              ) : (
                <FieldDescription>
                  {preview !== null ? `Stock after this operation: ${preview}` : "Enter a whole number greater than 0."}
                </FieldDescription>
              )}
            </Field>
          </FieldGroup>
          <DialogFooter>
            <DialogClose render={<Button type="button" variant="outline" />}>Cancel</DialogClose>
            <Button type="submit" disabled={isPending}>
              {isPending && <Spinner data-icon="inline-start" />}
              {isCheckOut ? "Check out" : "Restock"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
