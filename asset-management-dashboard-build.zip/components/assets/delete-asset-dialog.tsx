"use client"

import * as React from "react"
import { toast } from "sonner"
import { useInventory } from "@/components/inventory-provider"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Spinner } from "@/components/ui/spinner"
import type { Asset } from "@/lib/types"

interface DeleteAssetDialogProps {
  asset: Asset | null
  onOpenChange: (open: boolean) => void
}

export function DeleteAssetDialog({ asset, onOpenChange }: DeleteAssetDialogProps) {
  const { deleteAsset } = useInventory()
  const [isPending, startTransition] = React.useTransition()

  function handleDelete() {
    if (!asset) return
    startTransition(async () => {
      const result = await deleteAsset(asset)
      if (!result.ok) {
        toast.error("Could not delete asset", { description: result.error })
        return
      }
      toast.success("Asset deleted", { description: asset.name })
      onOpenChange(false)
    })
  }

  return (
    <AlertDialog open={asset !== null} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete {asset?.name}?</AlertDialogTitle>
          <AlertDialogDescription>
            This permanently removes <span className="font-mono">{asset?.sku}</span> and its stock record. Historical
            activity entries are kept for auditing.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction variant="destructive" onClick={handleDelete} disabled={isPending}>
            {isPending && <Spinner data-icon="inline-start" />}
            Delete asset
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}
