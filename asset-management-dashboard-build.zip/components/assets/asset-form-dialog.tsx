"use client"

import * as React from "react"
import { toast } from "sonner"
import { useInventory } from "@/components/inventory-provider"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Field, FieldError, FieldGroup, FieldLabel } from "@/components/ui/field"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Spinner } from "@/components/ui/spinner"
import { ASSET_CATEGORIES, type Asset, type AssetCategory } from "@/lib/types"

interface AssetFormDialogProps {
  open: boolean
  asset?: Asset
  onOpenChange: (open: boolean) => void
}

const categoryItems = ASSET_CATEGORIES.map((c) => ({ label: c, value: c }))

export function AssetFormDialog({ open, asset, onOpenChange }: AssetFormDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        {open && <AssetForm key={asset?.id ?? "new"} asset={asset} onDone={() => onOpenChange(false)} />}
      </DialogContent>
    </Dialog>
  )
}

function AssetForm({ asset, onDone }: { asset?: Asset; onDone: () => void }) {
  const { saveAsset } = useInventory()
  const [category, setCategory] = React.useState<AssetCategory>(asset?.category ?? "Electronics")
  const [error, setError] = React.useState<string | null>(null)
  const [isPending, startTransition] = React.useTransition()
  const isEdit = Boolean(asset)

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const form = new FormData(e.currentTarget)
    setError(null)
    startTransition(async () => {
      const result = await saveAsset(
        {
          sku: String(form.get("sku") ?? ""),
          name: String(form.get("name") ?? ""),
          category,
          location: String(form.get("location") ?? ""),
          quantity: Number(form.get("quantity")),
          unitPrice: Number(form.get("unitPrice")),
          reorderLevel: Number(form.get("reorderLevel")),
        },
        asset?.id,
      )
      if (!result.ok) {
        setError(result.error)
        return
      }
      toast.success(isEdit ? "Asset updated" : "Asset created", { description: result.data.name })
      onDone()
    })
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      <DialogHeader>
        <DialogTitle>{isEdit ? "Edit asset" : "Add new asset"}</DialogTitle>
        <DialogDescription>
          {isEdit ? "Update the details for this SKU." : "Register a new SKU in the inventory."}
        </DialogDescription>
      </DialogHeader>
      <FieldGroup>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field>
            <FieldLabel htmlFor="asset-sku">SKU</FieldLabel>
            <Input id="asset-sku" name="sku" required defaultValue={asset?.sku} placeholder="IT-LAP-001" className="font-mono" />
          </Field>
          <Field>
            <FieldLabel htmlFor="asset-category">Category</FieldLabel>
            <Select items={categoryItems} value={category} onValueChange={(v) => v && setCategory(v as AssetCategory)}>
              <SelectTrigger id="asset-category" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {categoryItems.map((item) => (
                    <SelectItem key={item.value} value={item.value}>
                      {item.label}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </Field>
        </div>
        <Field>
          <FieldLabel htmlFor="asset-name">Asset name</FieldLabel>
          <Input id="asset-name" name="name" required defaultValue={asset?.name} placeholder={'MacBook Pro 14"'} />
        </Field>
        <Field>
          <FieldLabel htmlFor="asset-location">Location</FieldLabel>
          <Input id="asset-location" name="location" required defaultValue={asset?.location} placeholder="HQ · Floor 3" />
        </Field>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field>
            <FieldLabel htmlFor="asset-quantity">Quantity</FieldLabel>
            <Input id="asset-quantity" name="quantity" type="number" min={0} step={1} required defaultValue={asset?.quantity ?? 0} />
          </Field>
          <Field>
            <FieldLabel htmlFor="asset-price">Unit price (USD)</FieldLabel>
            <Input id="asset-price" name="unitPrice" type="number" min={0} step="0.01" required defaultValue={asset?.unitPrice} />
          </Field>
          <Field>
            <FieldLabel htmlFor="asset-reorder">Reorder level</FieldLabel>
            <Input id="asset-reorder" name="reorderLevel" type="number" min={0} step={1} required defaultValue={asset?.reorderLevel ?? 5} />
          </Field>
        </div>
        {error && (
          <Field data-invalid>
            <FieldError>{error}</FieldError>
          </Field>
        )}
      </FieldGroup>
      <DialogFooter>
        <DialogClose render={<Button type="button" variant="outline" />}>Cancel</DialogClose>
        <Button type="submit" disabled={isPending}>
          {isPending && <Spinner data-icon="inline-start" />}
          {isEdit ? "Save changes" : "Create asset"}
        </Button>
      </DialogFooter>
    </form>
  )
}
