import { ActionBadge, ActivityStatusBadge } from "@/components/status-badges"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { formatDateTime, formatNumber, getInitials } from "@/lib/inventory"
import type { ActivityLog } from "@/lib/types"

export function ActivityTable({ entries }: { entries: ActivityLog[] }) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Action</TableHead>
          <TableHead>Asset / Subject</TableHead>
          <TableHead className="text-right">Qty</TableHead>
          <TableHead>Performed by</TableHead>
          <TableHead>Timestamp</TableHead>
          <TableHead>Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {entries.length === 0 ? (
          <TableRow>
            <TableCell colSpan={6} className="h-24 text-center text-muted-foreground">
              No activity matches your filters.
            </TableCell>
          </TableRow>
        ) : (
          entries.map((entry) => (
            <TableRow key={entry.id}>
              <TableCell>
                <ActionBadge action={entry.action} />
              </TableCell>
              <TableCell>
                <div className="flex flex-col">
                  <span className="font-medium">{entry.assetName}</span>
                  {entry.sku && <span className="font-mono text-xs text-muted-foreground">{entry.sku}</span>}
                </div>
              </TableCell>
              <TableCell className="text-right tabular-nums">
                {entry.quantity !== undefined ? formatNumber(entry.quantity) : "—"}
              </TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  <Avatar className="size-6">
                    <AvatarFallback className="text-[10px]">{getInitials(entry.performedBy)}</AvatarFallback>
                  </Avatar>
                  <span>{entry.performedBy}</span>
                </div>
              </TableCell>
              <TableCell className="text-muted-foreground tabular-nums">
                <time dateTime={entry.timestamp}>{formatDateTime(entry.timestamp)}</time>
              </TableCell>
              <TableCell>
                <ActivityStatusBadge status={entry.status} />
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  )
}
