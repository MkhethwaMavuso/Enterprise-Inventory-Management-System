"use client"

import * as React from "react"
import { SearchIcon } from "lucide-react"
import { ActivityTable } from "@/components/activity/activity-table"
import { useInventory } from "@/components/inventory-provider"
import { PageHeader } from "@/components/page-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { InputGroup, InputGroupAddon, InputGroupInput } from "@/components/ui/input-group"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"

const FILTERS = [
  { value: "all", label: "All" },
  { value: "movement", label: "Movements" },
  { value: "changes", label: "Changes" },
  { value: "users", label: "Users" },
] as const

type Filter = (typeof FILTERS)[number]["value"]

const FILTER_ACTIONS: Record<Exclude<Filter, "all">, string[]> = {
  movement: ["CHECK_OUT", "CHECK_IN", "RESTOCK"],
  changes: ["CREATE", "UPDATE", "DELETE"],
  users: ["USER_CREATED"],
}

export function ActivityView() {
  const { activity } = useInventory()
  const [filter, setFilter] = React.useState<Filter>("all")
  const [query, setQuery] = React.useState("")

  const entries = React.useMemo(() => {
    const q = query.trim().toLowerCase()
    return activity.filter((entry) => {
      if (filter !== "all" && !FILTER_ACTIONS[filter].includes(entry.action)) return false
      if (!q) return true
      return (
        entry.assetName.toLowerCase().includes(q) ||
        entry.performedBy.toLowerCase().includes(q) ||
        (entry.sku?.toLowerCase().includes(q) ?? false)
      )
    })
  }, [activity, filter, query])

  return (
    <>
      <PageHeader title="Activity Logs" description="A complete audit trail of every inventory and user action." />
      <Card>
        <CardHeader>
          <CardTitle>Audit Trail</CardTitle>
          <CardDescription>{entries.length} entries</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
            <ToggleGroup
              variant="outline"
              value={[filter]}
              onValueChange={(value) => value[0] && setFilter(value[0] as Filter)}
              aria-label="Filter by action type"
            >
              {FILTERS.map((f) => (
                <ToggleGroupItem key={f.value} value={f.value}>
                  {f.label}
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
            <InputGroup className="md:max-w-xs">
              <InputGroupAddon>
                <SearchIcon />
              </InputGroupAddon>
              <InputGroupInput
                type="search"
                placeholder="Search asset, SKU, or user…"
                aria-label="Search activity"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </InputGroup>
          </div>
          <ActivityTable entries={entries} />
        </CardContent>
      </Card>
    </>
  )
}
