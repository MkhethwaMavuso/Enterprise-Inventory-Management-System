import { ActivityIcon, BoxesIcon, LayoutDashboardIcon, SettingsIcon, UsersIcon, type LucideIcon } from "lucide-react"

export interface NavItem {
  title: string
  href: string
  icon: LucideIcon
}

export const NAV_ITEMS: NavItem[] = [
  { title: "Dashboard Overview", href: "/dashboard", icon: LayoutDashboardIcon },
  { title: "Assets Inventory", href: "/assets", icon: BoxesIcon },
  { title: "Users & Roles", href: "/users", icon: UsersIcon },
  { title: "Activity Logs", href: "/activity", icon: ActivityIcon },
  { title: "Settings", href: "/settings", icon: SettingsIcon },
]
