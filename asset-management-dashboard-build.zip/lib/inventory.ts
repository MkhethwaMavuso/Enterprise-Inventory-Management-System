import type { Asset, AssetStatus } from "@/lib/types"

export function getAssetStatus(asset: Pick<Asset, "quantity" | "reorderLevel">): AssetStatus {
  if (asset.quantity <= 0) return "Out of Stock"
  if (asset.quantity <= asset.reorderLevel) return "Low Stock"
  return "Available"
}

const currencyFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
})

const compactCurrencyFormatter = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  notation: "compact",
  maximumFractionDigits: 1,
})

const numberFormatter = new Intl.NumberFormat("en-US")

const dateTimeFormatter = new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  hour: "numeric",
  minute: "2-digit",
  timeZone: "UTC",
})

const dateFormatter = new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  year: "numeric",
  timeZone: "UTC",
})

export const formatCurrency = (value: number) => currencyFormatter.format(value)
export const formatCompactCurrency = (value: number) => compactCurrencyFormatter.format(value)
export const formatNumber = (value: number) => numberFormatter.format(value)
export const formatDateTime = (iso: string) => dateTimeFormatter.format(new Date(iso))
export const formatDate = (iso: string) => dateFormatter.format(new Date(iso))

export function getInitials(name: string) {
  return name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase()
}
