"use server"

import { ASSET_CATEGORIES, USER_ROLES } from "@/lib/types"
import type { ActionResult, Asset, AssetCategory, User, UserRole } from "@/lib/types"

// Server Action stubs. They validate input on the server and echo back the
// persisted record. Swap the bodies for real database calls when a backend is wired up.

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

function isPositiveInteger(value: number) {
  return Number.isInteger(value) && value > 0
}

export interface CreateUserInput {
  name: string
  email: string
  password: string
  role: UserRole
}

export async function createUserAction(input: CreateUserInput): Promise<ActionResult<User>> {
  const name = input.name?.trim()
  const email = input.email?.trim().toLowerCase()

  if (!name || name.length < 2) return { ok: false, error: "Full name must be at least 2 characters." }
  if (!email || !EMAIL_PATTERN.test(email)) return { ok: false, error: "Enter a valid email address." }
  if (!input.password || input.password.length < 8) return { ok: false, error: "Password must be at least 8 characters." }
  if (!USER_ROLES.includes(input.role)) return { ok: false, error: "Select a valid role." }

  // TODO: hash the password and insert the user into the database.
  return {
    ok: true,
    data: {
      id: `usr_${crypto.randomUUID().slice(0, 8)}`,
      name,
      email,
      role: input.role,
      status: "Active",
      createdAt: new Date().toISOString(),
    },
  }
}

export type QuantityOperation = "CHECK_OUT" | "RESTOCK"

export interface UpdateAssetQuantityInput {
  assetId: string
  currentQuantity: number
  amount: number
  operation: QuantityOperation
}

export async function updateAssetQuantityAction(
  input: UpdateAssetQuantityInput,
): Promise<ActionResult<{ assetId: string; quantity: number }>> {
  if (!isPositiveInteger(input.amount)) return { ok: false, error: "Quantity must be a positive whole number." }
  if (input.amount > 10_000) return { ok: false, error: "Quantity exceeds the maximum of 10,000 per transaction." }

  // TODO: read the current quantity from the database inside a transaction instead of trusting the client.
  const nextQuantity =
    input.operation === "CHECK_OUT" ? input.currentQuantity - input.amount : input.currentQuantity + input.amount

  if (nextQuantity < 0) return { ok: false, error: "Not enough stock available to check out." }

  return { ok: true, data: { assetId: input.assetId, quantity: nextQuantity } }
}

export type AssetInput = Omit<Asset, "id">

export async function saveAssetAction(input: AssetInput & { id?: string }): Promise<ActionResult<Asset>> {
  const sku = input.sku?.trim().toUpperCase()
  const name = input.name?.trim()

  if (!sku || sku.length < 3) return { ok: false, error: "SKU must be at least 3 characters." }
  if (!name) return { ok: false, error: "Asset name is required." }
  if (!ASSET_CATEGORIES.includes(input.category as AssetCategory)) return { ok: false, error: "Select a valid category." }
  if (!Number.isInteger(input.quantity) || input.quantity < 0) return { ok: false, error: "Quantity must be zero or more." }
  if (!Number.isFinite(input.unitPrice) || input.unitPrice < 0) return { ok: false, error: "Unit price must be zero or more." }
  if (!Number.isInteger(input.reorderLevel) || input.reorderLevel < 0) return { ok: false, error: "Reorder level must be zero or more." }

  // TODO: upsert the asset in the database.
  return {
    ok: true,
    data: {
      ...input,
      sku,
      name,
      location: input.location?.trim() || "Unassigned",
      id: input.id ?? `ast_${crypto.randomUUID().slice(0, 8)}`,
    },
  }
}

export async function deleteAssetAction(assetId: string): Promise<ActionResult<{ assetId: string }>> {
  if (!assetId) return { ok: false, error: "Missing asset id." }
  // TODO: delete the asset from the database.
  return { ok: true, data: { assetId } }
}
