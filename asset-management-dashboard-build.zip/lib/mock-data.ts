import type { ActivityLog, Asset, MovementPoint, User } from "@/lib/types"

export const CURRENT_USER: User = {
  id: "usr_001",
  name: "Amara Okafor",
  email: "amara.okafor@assetpulse.io",
  role: "ADMIN",
  status: "Active",
  createdAt: "2024-02-12T09:00:00.000Z",
}

export const initialAssets: Asset[] = [
  { id: "ast_001", sku: "EL-MBP-1601", name: 'MacBook Pro 16" M3', category: "Electronics", quantity: 42, unitPrice: 2499, reorderLevel: 10, location: "HQ — Floor 3" },
  { id: "ast_002", sku: "EL-DEL-U2723", name: "Dell UltraSharp 27 Monitor", category: "Electronics", quantity: 8, unitPrice: 579, reorderLevel: 12, location: "Warehouse A" },
  { id: "ast_003", sku: "EL-IPH-15P", name: "iPhone 15 Pro", category: "Electronics", quantity: 0, unitPrice: 999, reorderLevel: 5, location: "HQ — IT Desk" },
  { id: "ast_004", sku: "EL-LOG-MXK", name: "Logitech MX Keys", category: "Electronics", quantity: 118, unitPrice: 109, reorderLevel: 25, location: "Warehouse A" },
  { id: "ast_005", sku: "EL-SNY-WH5", name: "Sony WH-1000XM5 Headset", category: "Electronics", quantity: 4, unitPrice: 399, reorderLevel: 8, location: "HQ — IT Desk" },
  { id: "ast_006", sku: "FN-HMN-AER", name: "Herman Miller Aeron Chair", category: "Furniture", quantity: 64, unitPrice: 1395, reorderLevel: 15, location: "Warehouse B" },
  { id: "ast_007", sku: "FN-STD-DSK", name: "Electric Standing Desk", category: "Furniture", quantity: 31, unitPrice: 749, reorderLevel: 10, location: "Warehouse B" },
  { id: "ast_008", sku: "FN-CNF-TBL", name: "Conference Table 10-Seat", category: "Furniture", quantity: 2, unitPrice: 3200, reorderLevel: 3, location: "Warehouse B" },
  { id: "ast_009", sku: "FN-FIL-CAB", name: "Lockable Filing Cabinet", category: "Furniture", quantity: 27, unitPrice: 289, reorderLevel: 8, location: "HQ — Floor 2" },
  { id: "ast_010", sku: "IT-CSC-SW48", name: "Cisco Catalyst 48-Port Switch", category: "IT Equipment", quantity: 6, unitPrice: 4650, reorderLevel: 4, location: "Server Room" },
  { id: "ast_011", sku: "IT-DEL-R750", name: "Dell PowerEdge R750 Server", category: "IT Equipment", quantity: 3, unitPrice: 8900, reorderLevel: 4, location: "Server Room" },
  { id: "ast_012", sku: "IT-UBQ-AP6", name: "Ubiquiti U6 Access Point", category: "IT Equipment", quantity: 0, unitPrice: 179, reorderLevel: 10, location: "Warehouse A" },
  { id: "ast_013", sku: "IT-APC-UPS", name: "APC Smart-UPS 3000VA", category: "IT Equipment", quantity: 9, unitPrice: 1850, reorderLevel: 3, location: "Server Room" },
  { id: "ast_014", sku: "IT-YUB-K5", name: "YubiKey 5 NFC", category: "IT Equipment", quantity: 210, unitPrice: 55, reorderLevel: 50, location: "HQ — IT Desk" },
]

export const initialUsers: User[] = [
  CURRENT_USER,
  { id: "usr_002", name: "Daniel Reyes", email: "daniel.reyes@assetpulse.io", role: "MANAGER", status: "Active", createdAt: "2024-03-04T10:30:00.000Z" },
  { id: "usr_003", name: "Priya Natarajan", email: "priya.n@assetpulse.io", role: "EXECUTIVE", status: "Active", createdAt: "2024-01-18T08:15:00.000Z" },
  { id: "usr_004", name: "Marcus Lindqvist", email: "marcus.l@assetpulse.io", role: "STAFF", status: "Active", createdAt: "2024-05-22T13:45:00.000Z" },
  { id: "usr_005", name: "Sofia Bianchi", email: "sofia.bianchi@assetpulse.io", role: "STAFF", status: "Inactive", createdAt: "2024-06-09T11:00:00.000Z" },
  { id: "usr_006", name: "Kwame Mensah", email: "kwame.m@assetpulse.io", role: "MANAGER", status: "Active", createdAt: "2024-08-14T15:20:00.000Z" },
  { id: "usr_007", name: "Hannah Weiss", email: "hannah.weiss@assetpulse.io", role: "STAFF", status: "Active", createdAt: "2025-01-07T09:40:00.000Z" },
  { id: "usr_008", name: "Liam O'Connor", email: "liam.oconnor@assetpulse.io", role: "STAFF", status: "Inactive", createdAt: "2025-02-26T16:05:00.000Z" },
]

export const initialActivity: ActivityLog[] = [
  { id: "log_012", action: "CHECK_OUT", assetName: 'MacBook Pro 16" M3', sku: "EL-MBP-1601", quantity: 3, performedBy: "Daniel Reyes", timestamp: "2026-10-06T08:42:00.000Z", status: "Completed" },
  { id: "log_011", action: "RESTOCK", assetName: "Logitech MX Keys", sku: "EL-LOG-MXK", quantity: 50, performedBy: "Amara Okafor", timestamp: "2026-10-06T07:15:00.000Z", status: "Completed" },
  { id: "log_010", action: "CHECK_OUT", assetName: "Dell UltraSharp 27 Monitor", sku: "EL-DEL-U2723", quantity: 6, performedBy: "Marcus Lindqvist", timestamp: "2026-10-05T16:58:00.000Z", status: "Pending" },
  { id: "log_009", action: "CHECK_IN", assetName: "Sony WH-1000XM5 Headset", sku: "EL-SNY-WH5", quantity: 2, performedBy: "Hannah Weiss", timestamp: "2026-10-05T14:20:00.000Z", status: "Completed" },
  { id: "log_008", action: "CHECK_OUT", assetName: "iPhone 15 Pro", sku: "EL-IPH-15P", quantity: 5, performedBy: "Kwame Mensah", timestamp: "2026-10-05T11:03:00.000Z", status: "Flagged" },
  { id: "log_007", action: "UPDATE", assetName: "Dell PowerEdge R750 Server", sku: "IT-DEL-R750", performedBy: "Amara Okafor", timestamp: "2026-10-04T17:30:00.000Z", status: "Completed" },
  { id: "log_006", action: "CREATE", assetName: "YubiKey 5 NFC", sku: "IT-YUB-K5", quantity: 210, performedBy: "Daniel Reyes", timestamp: "2026-10-04T10:12:00.000Z", status: "Completed" },
  { id: "log_005", action: "USER_CREATED", assetName: "Hannah Weiss", performedBy: "Amara Okafor", timestamp: "2026-10-03T09:00:00.000Z", status: "Completed" },
  { id: "log_004", action: "CHECK_OUT", assetName: "Electric Standing Desk", sku: "FN-STD-DSK", quantity: 4, performedBy: "Kwame Mensah", timestamp: "2026-10-02T15:44:00.000Z", status: "Completed" },
  { id: "log_003", action: "RESTOCK", assetName: "Herman Miller Aeron Chair", sku: "FN-HMN-AER", quantity: 20, performedBy: "Daniel Reyes", timestamp: "2026-10-02T08:30:00.000Z", status: "Completed" },
  { id: "log_002", action: "DELETE", assetName: "Legacy Projector XG-20", sku: "EL-PRJ-XG20", performedBy: "Amara Okafor", timestamp: "2026-10-01T12:10:00.000Z", status: "Completed" },
  { id: "log_001", action: "CHECK_IN", assetName: "Cisco Catalyst 48-Port Switch", sku: "IT-CSC-SW48", quantity: 1, performedBy: "Marcus Lindqvist", timestamp: "2026-09-30T13:25:00.000Z", status: "Completed" },
]

export const movementTrend: MovementPoint[] = [
  { date: "Sep 30", checkIn: 18, checkOut: 24 },
  { date: "Oct 01", checkIn: 32, checkOut: 21 },
  { date: "Oct 02", checkIn: 26, checkOut: 35 },
  { date: "Oct 03", checkIn: 14, checkOut: 19 },
  { date: "Oct 04", checkIn: 41, checkOut: 28 },
  { date: "Oct 05", checkIn: 22, checkOut: 38 },
  { date: "Oct 06", checkIn: 35, checkOut: 27 },
]
