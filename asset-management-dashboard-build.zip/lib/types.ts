export const ASSET_CATEGORIES = ["Electronics", "Furniture", "IT Equipment"] as const
export type AssetCategory = (typeof ASSET_CATEGORIES)[number]

export type AssetStatus = "Available" | "Low Stock" | "Out of Stock"

export interface Asset {
  id: string
  sku: string
  name: string
  category: AssetCategory
  quantity: number
  unitPrice: number
  reorderLevel: number
  location: string
}

export const USER_ROLES = ["ADMIN", "MANAGER", "STAFF", "EXECUTIVE"] as const
export type UserRole = (typeof USER_ROLES)[number]

export type UserStatus = "Active" | "Inactive"

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  status: UserStatus
  createdAt: string
}

export type ActivityAction = "CHECK_OUT" | "CHECK_IN" | "RESTOCK" | "CREATE" | "UPDATE" | "DELETE" | "USER_CREATED"

export type ActivityStatus = "Completed" | "Pending" | "Flagged"

export interface ActivityLog {
  id: string
  action: ActivityAction
  assetName: string
  sku?: string
  quantity?: number
  performedBy: string
  timestamp: string
  status: ActivityStatus
}

export interface MovementPoint {
  date: string
  checkIn: number
  checkOut: number
}

export type ActionResult<T> = { ok: true; data: T } | { ok: false; error: string }
